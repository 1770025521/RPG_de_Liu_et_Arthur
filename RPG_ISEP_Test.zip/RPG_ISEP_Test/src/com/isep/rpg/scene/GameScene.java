package com.isep.rpg.scene;

import com.isep.rpg.Controller.enterController;
import com.isep.rpg.Director;
import com.isep.rpg.gamespartie.*;
import com.isep.rpg.util.Direction;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


import java.util.ArrayList;
import java.util.List;

public class GameScene extends enterController {
    protected Stage stage1;
    protected Canvas canvas =new Canvas(Director.WIDTH,Director.HEIGHT);
    private GraphicsContext graphicsContext =canvas.getGraphicsContext2D();

    private KeyProcess keyProcess= new KeyProcess();
    private Refresh refresh = new Refresh();
    private boolean running = false;
    private Background background =new Background();
    private Teams self =new Teams(200,150, Direction.stop);
    //private Boss boss=new Boss(500,250,70,60);
    public List<Enemy> enemys =new ArrayList<>();

    private void paint()  {

        background.paint(graphicsContext);
        self.paint(graphicsContext);
        try {
            if (self.impact(enemys)){
                self.impact(enemys);
                fight f=new fight();
                f.init(stage1);
//                Button b1=new Button("");
//                b1.setLayoutX(100);
//                b1.setLayoutY(100);
//                ImageView imageView=new ImageView();
//                Image image = new Image("image/frightbc.png",Director.WIDTH,Director.HEIGHT,false,false);
//                imageView.setImage(image);
//
//                AnchorPane root =new AnchorPane(canvas);
//                root.getChildren().add(imageView);
//                root.getChildren().addAll(b1);
//
//                stage1.setScene(new Scene(root,Director.WIDTH,Director.HEIGHT));

            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //boss.paint(graphicsContext);
        for (Enemy e:enemys){
            e.paint(graphicsContext);
        }



    }

    public void init(Stage stage){
        AnchorPane root =new AnchorPane(canvas);
        stage.getScene().setRoot(root);
        stage.getScene().setOnKeyReleased(keyProcess);
        stage.getScene().setOnKeyPressed(keyProcess);
        stage1=stage;

     //   boss.paint(graphicsContext);
        initEnemy();
        running=true;
        refresh.start();

    }
    private void initEnemy(){

        Enemy boss =new Boss(500,250,70,60);
        Enemy shuiguai =new BasicEnemy1(240,28,50,50);
        Enemy caoguai =new BasicEnemy2(100,280,50,50);
        enemys.add(boss);
        enemys.add(shuiguai);
        enemys.add(caoguai);
    }

    public void clear(Stage stage){
        stage.getScene().removeEventHandler(KeyEvent.KEY_RELEASED,keyProcess);
        refresh.stop();
    }
    private class Refresh extends AnimationTimer {

        @Override
        public void handle(long l) {
            if (running){
                paint();

            }


        }
    }

    private class KeyProcess implements EventHandler<KeyEvent> {

        @Override
        public void handle(KeyEvent event) {
            KeyCode keyCode =event.getCode();

            if (event.getEventType()==KeyEvent.KEY_RELEASED){
                self.released(keyCode);

            }else if(event.getEventType()==KeyEvent.KEY_PRESSED){
                self.pressed(keyCode);
            }

        }
    }
}
