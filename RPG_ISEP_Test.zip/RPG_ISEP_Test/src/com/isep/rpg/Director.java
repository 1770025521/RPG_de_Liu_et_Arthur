package com.isep.rpg;

import com.isep.rpg.scene.Index;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Director {
    public static final double WIDTH = 640,HEIGHT=360 ;
    private static Director instance =new Director();
    private Stage stage;


    private Director(){}

    public static Director getInstance(){
        return instance;
    }
    public  void init(Stage stage){
        AnchorPane root =new AnchorPane();
        Scene scene=new Scene(root,WIDTH,HEIGHT);
        stage.setTitle("RPG de Liu Yuze");
        stage.getIcons().add(new Image("resourse\\image\\rpgicon.png"));
        stage.setResizable(false);
        stage.setScene(scene);
        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);
        this.stage=stage;
        toIndex();
        stage.show();
    }
    public void toIndex(){
        Index.load(stage);

    }
    public void gameOver(){

    }
    public void gameStart(Stage stage){
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/fxml/enter.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Scene scene=new Scene(root,WIDTH,HEIGHT);
        stage.setTitle("RPG de Liu Yuze");
        stage.getIcons().add(new Image("resourse\\image\\rpgicon.png"));
        stage.setResizable(false);
        stage.setScene(scene);
        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);
        this.stage=stage;

        stage.show();


    }
}
