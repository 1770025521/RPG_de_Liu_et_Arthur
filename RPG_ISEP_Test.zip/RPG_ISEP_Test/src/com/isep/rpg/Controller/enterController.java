package com.isep.rpg.Controller;


import com.isep.rpg.scene.Enter;
import com.isep.rpg.scene.GameScene;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class enterController implements Initializable {
    //static ObservableList<String> choixdeherosList = FXCollections.observableArrayList("Mage","Healer","Hunter");

//    private static ChoiceBox<String> choixdeheros=new ChoiceBox<>();
//    static {
//        choixdeheros.setItems(choixdeherosList);
//
//    }
    @FXML
    private Label classhero;

    @FXML
    private Button startbutton;
    @FXML
    ChoiceBox<String> choixdeheros;
    @FXML
    private Button startgamebutton;

    @FXML
    private Button supprimbutton;
    int i=0;
    int j=0;
    public List<String> he=new ArrayList<>();

    public static List<String> Chucun=new ArrayList<>();


//    public int manat(){
//
//
//        if (he.contains("Hunter")|| he.contains("Warrior")){
//            for (int i=0;i<he.size();i++){
//                if (he.get(i)=="Hunter"||he.get(i)=="Warrior"){
//                    mpt-=100;
//                }
//            }
//
//        }
//        return mpt;
//    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        choixdeheros.getItems().addAll("Healer","Mage","Hunter","Warrior");

        startbutton.setOnAction(e->{
            if (i<3){

                he.add(choixdeheros.getValue());
                printvalue(he);
                i++;}else {
                j=1;
            }
            if (j==1){
                classhero.setText("Vous avez atteint le nombre maximum de h��ros que vous avez s��lectionn��s, veuillez ne pas les ajouter �� nouveau.");
                j=0;
            }


        });
        supprimbutton.setOnAction(e ->{
            int nomhe=he.size();
            if (he.isEmpty()){
                classhero.setText("Vous n'avez pas encore ajout�� de h��ros");
            }else {
                he.remove(nomhe-1);
                printvalue(he);
                i--;
            }
        });
        Chucun=he;

        startgamebutton.setOnAction(e ->{
            if (i==0){
                classhero.setText("Vous n'avez pas encore ajout�� de h��ros, vous devez ajouter au moins un h��ros pour commencer le jeu.");
            }else {
                FXMLLoader fxmlLoader = new FXMLLoader(Enter.class.getResource("/fxml/games.fxml"));
                Scene scene = null;
                try {
                    scene = new Scene(fxmlLoader.load());
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                Stage stage = new Stage();

                stage.setTitle("Main de RPG");
                stage.getIcons().add(new Image("resourse\\image\\rpgicon.png"));
                stage.setScene(scene);
                GameScene gameScene=new GameScene();
                gameScene.init(stage);
                stage.show();




                Stage stage1 = (Stage)startgamebutton.getScene().getWindow();
                stage1.close();
            }
        });
    }
    private void printvalue(List he){
        String a =String.valueOf(he).replace("["," ");
        String b= a.replace("]"," ");
        classhero.setText(b);
    }

}
