package com.isep.rpg.util;

public enum Direction {
    up,down,left,right,stop;
}
