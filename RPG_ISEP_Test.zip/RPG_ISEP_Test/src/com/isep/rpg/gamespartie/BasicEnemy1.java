package com.isep.rpg.gamespartie;

import javafx.scene.image.Image;

public class BasicEnemy1 extends Enemy{
    public BasicEnemy1(double x, double y, double width, double height) {
        super(new Image("image/shuiguai.png"), x, y, width, height);
    }


    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void removeEqu(int i) {

    }

    @Override
    public void levelup() {

    }
}
