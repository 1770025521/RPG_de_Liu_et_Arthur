package com.isep.rpg.gamespartie;

import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;

public class BasicEnemy1 extends Enemy{

    public BasicEnemy1(double x, double y, double width, double height) {
        super(new Image("image/shuiguai.png"), x, y, width, height);
    }

    public BasicEnemy1(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }

    @Override
    public double getHp() {
        return super.getHp();
    }

    @Override
    public double getMaxHp() {
        return 1000;
    }

    @Override
    public double getLastMp() {
        return super.getLastMp();
    }

    @Override
    public double getLastHp() {
        return super.getLastHp();
    }

    @Override
    public double getMp() {
        return 1000;
    }

    @Override
    public double getMaxMp() {
        return super.getMaxMp();
    }

    @Override
    public int getAtk() {
        return super.getAtk();
    }

    @Override
    public int getDef() {
        return super.getDef();
    }

    @Override
    public int getLv() {
        return super.getLv();
    }

    @Override
    public int getExp() {
        return super.getExp();
    }

    @Override
    public String getBodypath() {
        return super.getBodypath();
    }

    @Override
    public Rectangle2D getContour() {
        return super.getContour();
    }

    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void removeEqu(int i) {

    }

    @Override
    public void levelup() {

    }
}
