package com.isep.rpg.gamespartie;

public interface Consumable {

    void eat();
    void boire();


}
