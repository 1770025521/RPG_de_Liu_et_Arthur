package com.isep.rpg.gamespartie;

public interface Consumable {
}
