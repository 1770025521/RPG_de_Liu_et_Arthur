package com.isep.rpg.gamespartie;

import javafx.scene.image.Image;

public abstract class Enemy extends Role{


    public Enemy(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }
}
