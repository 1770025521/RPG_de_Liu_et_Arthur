package com.isep.rpg.gamespartie;

import javafx.scene.image.Image;

public abstract class Enemy extends Role{


    public Enemy(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }

    public Enemy(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv, Image image, double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3) {
        super(name, hp, maxHp, mp, maxMp, atk, def, lv, image, x, y, width, height, bodypath, sName1, sName2, sName3);
    }
}
