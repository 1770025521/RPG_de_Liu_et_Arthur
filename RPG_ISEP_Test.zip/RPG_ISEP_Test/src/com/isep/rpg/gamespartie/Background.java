package com.isep.rpg.gamespartie;

import com.isep.rpg.Director;
import javafx.scene.image.Image;

public class Background extends Role{
    public Background(){

        super(new Image("image/gamebackgroud.png"),0,0, Director.WIDTH,Director.HEIGHT);
    }

    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void removeEqu(int i) {

    }

    @Override
    public void levelup() {

    }
}
