package com.isep.rpg.gamespartie;

import com.isep.rpg.Director;
import com.isep.rpg.scene.GameScene;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.util.List;

import static com.isep.rpg.gamespartie.Teams.shibie;

public class fight extends GameScene {
    String skhunter="Tir";
    String skhealer="Traitement";
    String skmage="fireboll";
    String skwarrior="Decapitation";

    String bn1;
    String bn2;
    String bn3;

    int TeamHP;
    int TeamMP;


    Button b4=new Button("Food");
    Button b5=new Button("Potion");

    Label labelhero=new Label();
    Label labelenemy=new Label();
    ImageView imageView4=new ImageView();

    private void Fight(){
        boolean fightFlag=true;
        labelenemy.setText("HP:"+shibie.getMaxHp()+"MP:"+shibie.getMaxMp());
        labelhero.setText("HP:"+TeamHP+"MP:"+TeamMP);
        while (fightFlag){



        }
    }



    private void Tianjia(List<String> he){

            if (he.contains("Mage")&&bn1==null){
                bn1=skmage;
            } else  if (he.contains("Mage")&&bn2==null){
                bn2=skmage;
            }else  if (he.contains("Mage")&&bn3==null) {
                bn3 = skmage;
            }
            if (he.contains("Healer")&&bn2==null) {
                bn2=skhealer;

            } else if (he.contains("Healer")&&bn1==null) {
                bn1=skhealer;
            } else if (he.contains("Healer")&&bn3==null) {
                bn3=skhealer;
            }
            if (he.contains("Warrior")&&bn3==null) {
                bn3=skwarrior;
            }else if (he.contains("Warrior")&&bn1==null) {
                bn1=skwarrior;
            }else if (he.contains("Warrior")&&bn2==null) {
                bn2=skwarrior;
            }
            if (he.contains("Hunter")&&bn1==null) {
                bn1=skhunter;
            }else if (he.contains("Hunter")&&bn2==null) {
                bn2=skhunter;
            }else if (he.contains("Hunter")&&bn3==null) {
                bn3=skhunter;
            }



    }

    public void init(Stage stage1){
        Tianjia(Chucun);

        Button b1=new Button(bn1);
        Button b2=new Button(bn2);
        Button b3=new Button(bn3);

        b1.setLayoutX(30);
        b1.setLayoutY(250);
        b2.setLayoutX(150);
        b2.setLayoutY(250);
        b3.setLayoutX(270);
        b3.setLayoutY(250);
        b4.setLayoutX(390);
        b4.setLayoutY(250);
        b5.setLayoutX(510);
        b5.setLayoutY(250);


        ImageView imageView=new ImageView();
        ImageView imageView1=new ImageView();
        ImageView imageView2=new ImageView();
        ImageView imageView3=new ImageView();
        ImageView imageView4=new ImageView();
        Image imagebc = new Image("image/frightbc.png",Director.WIDTH,Director.HEIGHT,false,false);
        boolean flag1 = false;
        boolean flag2= false;
        boolean flag3= false;
        if (Chucun.contains("Mage")&&flag1==false){
            Image imagema1=new Image("image/mage.png",40,40,false,false);
            imageView1.setImage(imagema1);
            imageView1.setX(20);
            imageView1.setY(190);
            flag1=true;
        }else if (Chucun.contains("Mage")&&flag2==false){
            Image imagema2=new Image("image/mage.png",40,40,false,false);
            imageView2.setImage(imagema2);
            imageView2.setX(70);
            imageView2.setY(190);
            flag2=true;
        }else if (Chucun.contains("Mage")&&flag3==false){
            Image imagema3=new Image("image/mage.png",40,40,false,false);
            imageView3.setImage(imagema3);
            imageView3.setX(120);
            imageView3.setY(190);
            flag3=true;
        }
        if (Chucun.contains("Warrior")&&flag1==false){
            Image imagema1=new Image("image/warrior.png",40,40,false,false);
            imageView1.setImage(imagema1);
            imageView1.setX(20);
            imageView1.setY(190);
            flag1=true;
        }else  if (Chucun.contains("Warrior")&&flag2==false){
            Image imagema2=new Image("image/warrior.png",40,40,false,false);
            imageView2.setImage(imagema2);
            imageView2.setX(70);
            imageView2.setY(190);
            flag2=true;
        }else  if (Chucun.contains("Warrior")&&flag3==false){
            Image imagema3=new Image("image/warrior.png",40,40,false,false);
            imageView3.setImage(imagema3);
            imageView3.setX(120);
            imageView3.setY(190);
            flag3=true;
        }
        if (Chucun.contains("Healer")&&flag1==false){
            Image imagema1=new Image("image/healer.png",40,40,false,false);
            imageView1.setImage(imagema1);
            imageView1.setX(20);
            imageView1.setY(190);
            flag1=true;
        }else if (Chucun.contains("Healer")&&flag2==false){
            Image imagema2=new Image("image/healer.png",40,40,false,false);
            imageView2.setImage(imagema2);
            imageView2.setX(70);
            imageView2.setY(190);
            flag2=true;
        }else if (Chucun.contains("Healer")&&flag3==false){
            Image imagema3=new Image("image/healer.png",40,40,false,false);
            imageView3.setImage(imagema3);
            imageView3.setX(120);
            imageView3.setY(190);
            flag3=true;
        }
        if (Chucun.contains("Hunter")&&flag1==false){
            Image imagema1=new Image("image/hunter.png",40,40,false,false);
            imageView1.setImage(imagema1);
            imageView1.setX(20);
            imageView1.setY(190);
            flag1=true;
        }else if (Chucun.contains("Hunter")&&flag2==false){
            Image imagema2=new Image("image/hunter.png",40,40,false,false);
            imageView2.setImage(imagema2);
            imageView2.setX(70);
            imageView2.setY(190);
            flag2=true;
        }else if (Chucun.contains("Hunter")&&flag3==false){
            Image imagema3=new Image("image/hunter.png",40,40,false,false);
            imageView3.setImage(imagema3);
            imageView3.setX(120);
            imageView3.setY(190);
            flag3=true;
        }



        
        imageView.setImage(imagebc);


        if (shibie instanceof Boss){
            Image imagema4=new Image("image/longfight.png",160,160,false,false);
            imageView4.setImage(imagema4);
            imageView4.setX(400);
            imageView4.setY(67);
        }else  if (shibie instanceof BasicEnemy1){
            Image imagema4=new Image("image/shuiguaifight.png",160,160,false,false);
            imageView4.setImage(imagema4);
            imageView4.setX(400);
            imageView4.setY(67);
        }else  if (shibie instanceof BasicEnemy2){
            Image imagema4=new Image("image/caoguaifight.png",160,160,false,false);
            imageView4.setImage(imagema4);
            imageView4.setX(400);
            imageView4.setY(67);
        }

        if (Chucun.contains("Mage")){
           Mage mage= new Mage(100,100,150,150,30,20);
           TeamHP+=100;
           TeamMP+=150;
        }else  if (Chucun.contains("Hunter")){
            Hunter hunter = new Hunter(100,100,0,0,40,10,10);
            TeamHP+=100;
            TeamMP+=0;
        }else  if (Chucun.contains("Warrior")){
            Warrior warrior= new Warrior(300,300,0,0,20,60);
            TeamHP+=300;
            TeamMP+=0;
        }else  if (Chucun.contains("Healer")){
            Healer healer= new Healer(100,100,250,250,10,10);
            TeamHP+=100;
            TeamMP+=250;
        }









        AnchorPane root =new AnchorPane(canvas);
        root.getChildren().addAll(imageView,imageView1,imageView2,imageView3,imageView4);
        root.getChildren().addAll(b1,b2,b3,b4,b5);

        stage1.setScene(new Scene(root,Director.WIDTH,Director.HEIGHT));
    }



}
