package com.isep.rpg.gamespartie;

import com.isep.rpg.Director;
import com.isep.rpg.scene.GameScene;
import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class fight extends GameScene {
    String skhunter="shejian";
    String skhealer="zhiliao";
    String skmage="huoqiu";
    String skwarrior="zhansha";

    Button b1=new Button("s");
    Button b2=new Button("s");
    Button b3=new Button("s");
    Button b4=new Button("Food");
    Button b5=new Button("Potion");

    public void init(Stage stage1){

        b1.setLayoutX(100);
        b1.setLayoutY(100);
        ImageView imageView=new ImageView();
        Image image = new Image("image/frightbc.png",Director.WIDTH,Director.HEIGHT,false,false);
        imageView.setImage(image);

        AnchorPane root =new AnchorPane(canvas);
        root.getChildren().add(imageView);
        root.getChildren().addAll(b1);

        stage1.setScene(new Scene(root,Director.WIDTH,Director.HEIGHT));
    }

}
