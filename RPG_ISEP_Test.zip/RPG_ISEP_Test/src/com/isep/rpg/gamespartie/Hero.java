package com.isep.rpg.gamespartie;

import com.isep.rpg.util.Direction;
import javafx.scene.image.Image;

import java.util.HashMap;
import java.util.Map;

public abstract class  Hero extends Role{
    boolean alive =true;
    Direction dir;
    double speed;


    Hero(Image image,double x,double y,double width,double height,Direction dir){
        super(image, x, y, width, height);
        this.dir=dir;
    }

    public Hero(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv,  double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3,Direction dir) {
        super(name, hp, maxHp, mp, maxMp, atk, def, lv, null, x, y, width, height, bodypath, sName1, sName2, sName3);
        this.dir=dir;
    }

    public Hero(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv, Image image, double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3) {
        super(name, hp, maxHp, mp, maxMp, atk, def, lv, image, x, y, width, height, bodypath, sName1, sName2, sName3);
    }

    public abstract void move();
    public abstract boolean impactChecking(Role role);







}