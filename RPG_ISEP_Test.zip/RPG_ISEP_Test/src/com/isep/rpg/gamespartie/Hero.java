package com.isep.rpg.gamespartie;

import javafx.scene.image.Image;

public class  Hero extends Role{


    public Hero(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv, Image image, double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3) {
        super(name, hp, maxHp, mp, maxMp, atk, def, lv, image, x, y, width, height, bodypath, sName1, sName2, sName3);
    }



    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void levelup() {

    }

    @Override
    public void removeEqu(int i) {

    }

}