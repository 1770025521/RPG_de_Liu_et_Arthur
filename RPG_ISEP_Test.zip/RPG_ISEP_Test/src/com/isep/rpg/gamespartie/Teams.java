package com.isep.rpg.gamespartie;

import com.isep.rpg.Director;

import com.isep.rpg.util.Direction;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

import java.util.List;

public class Teams extends Hero{
    int flag=0;
    double oldx,oldy;

    boolean keyup,keydown,keyleft,keyright;
    public Teams(double x, double y, Direction dir){
        super(new Image("image/renwu_down.png"),x,y,50,40,dir);
        speed=5;
        imageMap.put("up",new Image("image/renwu_up.png"));
        imageMap.put("right",new Image("image/renwu_right.png"));
        imageMap.put("left",new Image("image/renwu_left.png"));
        imageMap.put("down",new Image("image/renwu_down.png"));
    }



    public Teams(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv, double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3, Direction dir) {
        super("Equipe RPG", hp, maxHp, mp, maxMp, atk, def, lv, x, y, width, height, bodypath, sName1, sName2, sName3, dir);
        imageMap.put("up",new Image("image/renwu_up.png"));
        imageMap.put("right",new Image("image/renwu_right.png"));
        imageMap.put("left",new Image("image/renwu_left.png"));
        imageMap.put("down",new Image("image/renwu_down.png"));
    }



    public void pressed(KeyCode keyCode){
        switch (keyCode){
            case UP :
                keyup=true;
                break;
            case DOWN:
                keydown=true;
                break;
            case LEFT:
                keyleft=true;
                break;
            case RIGHT:
                keyright=true;
                break;

        }
        redirect();

    }

    public void released(KeyCode keyCode){
        switch (keyCode){
            case UP :
                keyup=false;
                break;
            case DOWN:
                keydown=false;
                break;
            case LEFT:
                keyleft=false;
                break;
            case RIGHT:
                keyright=false;
                break;

        }
        redirect();
    }
    public void redirect(){
        if (keyup && !keydown && !keyleft && !keyright)dir =Direction.up;
        else if (!keyup && keydown && !keyleft && !keyright)dir =Direction.down;
        else if (!keyup && !keydown && keyleft && !keyright)dir =Direction.left;
        else if (!keyup && !keydown && !keyleft && keyright)dir =Direction.right;
        else if (!keyup && !keydown && !keyleft && !keyright)dir =Direction.stop;

    }

    @Override
    public void move() {
        oldx=x;
        oldy=y;
        switch (dir){
            case up:
                y-=speed;
                break;
            case down:
                y+=speed;
                break;
            case left:
                x-=speed;
                break;
            case right:
                x+=speed;
                break;

        }
        if (x<0) x=0;
        if (y<0) y=0;
        if (x> Director.WIDTH-width+10)x=Director.WIDTH-width+10;
        if (y>Director.HEIGHT-height)y=Director.HEIGHT-height;
    }

    @Override
    public void paint(GraphicsContext graphicsContext) {
        super.paint(graphicsContext);
//        if (flag==0){
//            image=imageMap.get("down");
//            flag++;
//        }

        switch (dir){

            case up:
                image=imageMap.get("up");
                break;
            case down:
                image=imageMap.get("down");
                break;
            case left:
                image=imageMap.get("left");
                break;
            case right:
                image=imageMap.get("right");
                break;

        }
       // super.paint(graphicsContext);
        move();
    }

    public boolean impact(Enemy enemy){
        if (enemy!=null&&getContour().intersects(enemy.getContour())){
            x=oldx;
            y=oldy;
            return true;
        }
        return false;
    }
    public boolean impact(List<Enemy> enemys) throws InterruptedException {
        for (Enemy e:enemys){
            if (impact(e)){
                impact(e);
                return true;

            }





        }
        return false;


    }


    @Override
    public boolean impactChecking(Role role) {
        return false;
    }

    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void removeEqu(int i) {

    }

    @Override
    public void levelup() {

    }
}
