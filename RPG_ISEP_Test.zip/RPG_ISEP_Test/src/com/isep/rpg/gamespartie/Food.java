package com.isep.rpg.gamespartie;

public class Food implements Consumable{
}
