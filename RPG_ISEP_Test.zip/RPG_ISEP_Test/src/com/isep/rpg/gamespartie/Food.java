package com.isep.rpg.gamespartie;

public class Food implements Consumable{
    @Override
    public void eat() {

    }

    @Override
    public void boire() {


    }
}
