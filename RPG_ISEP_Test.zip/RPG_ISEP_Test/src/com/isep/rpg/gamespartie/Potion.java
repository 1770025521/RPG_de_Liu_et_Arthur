package com.isep.rpg.gamespartie;

public class Potion implements Consumable{
    @Override
    public void eat() {

    }

    @Override
    public void boire() {

    }
}
