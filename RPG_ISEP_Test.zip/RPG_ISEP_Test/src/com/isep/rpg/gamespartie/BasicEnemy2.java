package com.isep.rpg.gamespartie;

import javafx.scene.image.Image;

public class BasicEnemy2 extends Enemy{
    private double maxHP=1000;
    private double maxMP=1000;
    public BasicEnemy2(double x, double y, double width, double height) {
        super(new Image("image/caoguai.png"), x, y, width, height);
    }
    public BasicEnemy2(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }



    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void removeEqu(int i) {

    }

    @Override
    public void levelup() {

    }
}

