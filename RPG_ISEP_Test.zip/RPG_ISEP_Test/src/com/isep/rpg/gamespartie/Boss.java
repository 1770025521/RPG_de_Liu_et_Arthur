package com.isep.rpg.gamespartie;


import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Boss extends Enemy{
    private double maxHP=1000;
    private double maxMP=1000;
    public Boss(double x, double y, double width, double height) {
        super(new Image("image/boss.png"), x, y, width, height);


    }









    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {
        // TODO 自动生成的方法存根
        this.setLastMp(this.getMp());
        this.setMp(this.getMp()-0.3*this.getMaxMp());
        if(this.getMp() <=0) {
            this.setMp(this.getLastMp());

            return;
        }else {

            this.setLastHp(this.getHp());
            this.setHp(this.getHp()+(this.getMaxHp()-this.getHp())*0.2);
        }

    }

    @Override
    public void skill3(Role role) {

    }




    @Override
    public void equipment(int i) {
        // TODO 自动生成的方法存根

    }

    @Override
    public void levelup() {
        // TODO 自动生成的方法存根

    }

    @Override
    public void removeEqu(int i) {
        // TODO 自动生成的方法存根

    }

    @Override
    public void paint(GraphicsContext graphicsContext) {

        super.paint(graphicsContext);
    }
}
