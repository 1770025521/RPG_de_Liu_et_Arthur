package com.isep.rpg.gamespartie;

import com.isep.rpg.util.Direction;
import javafx.scene.image.Image;

public class Hunter extends Hero{


    Hunter(Image image, double x, double y, double width, double height, Direction dir) {
        super(image, x, y, width, height, dir);
    }

    public Hunter(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv, double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3, Direction dir) {
        super(name, hp, maxHp, mp, maxMp, atk, def, lv, x, y, width, height, bodypath, sName1, sName2, sName3, dir);
    }

    public Hunter(String name, double hp, double maxHp, double mp, double maxMp, int atk, int def, int lv, Image image, double x, double y, double width, double height, String bodypath, String sName1, String sName2, String sName3) {
        super(name, hp, maxHp, mp, maxMp, atk, def, lv, image, x, y, width, height, bodypath, sName1, sName2, sName3);
    }

    @Override
    public void move() {

    }

    @Override
    public boolean impactChecking(Role role) {
        return false;
    }

    @Override
    public void attack(int skill, Role role) {

    }

    @Override
    public void skill1(Role role) {

    }

    @Override
    public void skill2() {

    }

    @Override
    public void skill3(Role role) {

    }

    @Override
    public void equipment(int i) {

    }

    @Override
    public void removeEqu(int i) {

    }

    @Override
    public void levelup() {

    }
}
